## To Run ##

1) Navigate to folder of zip extract in terminal

2) Run 'python .\HW1_MasonHolcombe.py'