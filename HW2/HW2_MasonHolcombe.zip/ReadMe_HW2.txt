## To Run HW2_MasonHolcombe.py ##

1) Navigate to folder of zip extract in terminal

2) Install dependencies with 'pip install -r requirements.txt'

3) Run 'python .\HW2_MasonHolcombe.py'